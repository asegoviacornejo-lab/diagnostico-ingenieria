from __future__ import annotations

from copy import deepcopy


def default_user_data() -> dict:
    return {
        "configuracion": {
            "valor_sct_horas": 27.0,
            "semanas_semestre": 18,
        },
        "asignaturas": [
            {"nombre": "Calculo III", "sct": 6.0},
            {"nombre": "Fisica II", "sct": 5.0},
            {"nombre": "Programacion", "sct": 4.0},
        ],
        "sueno": {
            "horas_normales": 6.5,
            "horas_recuperacion": 8.0,
        },
        "tiempo": {
            "horas_disponibles": 30.0,
            "horas_trabajo": 0.0,
            "horas_traslado": 5.0,
            "actividades_personales": "",
        },
        "estado": {
            "comprension": 3,
            "organizacion": 3,
            "motivacion": 3,
            "estres": 3,
        },
    }


def merge_with_defaults(data: dict | None) -> dict:
    merged = default_user_data()
    if not isinstance(data, dict):
        return merged

    for section, value in data.items():
        if section == "asignaturas" and isinstance(value, list):
            merged[section] = value
        elif isinstance(value, dict) and isinstance(merged.get(section), dict):
            merged[section].update(value)
    return deepcopy(merged)


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def apply_page_style() -> None:
    import streamlit as st

    st.markdown(
        """
        <style>
        :root {
            --accent: #2563eb;
            --ok: #15803d;
            --warn: #b45309;
            --danger: #b91c1c;
            --panel: #f8fafc;
            --line: #d9e2ec;
        }

        .block-container {
            padding-top: 2rem;
            padding-bottom: 3rem;
            max-width: 1180px;
        }

        div[data-testid="stMetric"] {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 1rem;
        }

        .status-card {
            border-radius: 8px;
            padding: 1rem 1.2rem;
            border: 1px solid var(--line);
            margin: 0.5rem 0 1rem 0;
        }

        .status-verde {
            background: #ecfdf3;
            border-color: #bbf7d0;
        }

        .status-amarillo {
            background: #fffbeb;
            border-color: #fde68a;
        }

        .status-rojo {
            background: #fef2f2;
            border-color: #fecaca;
        }

        .small-muted {
            color: #64748b;
            font-size: 0.92rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )
